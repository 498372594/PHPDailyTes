<?php
session_start();
$id=$_SESSION['uid'];
$pdo=new PDO("mysql:host=127.0.0.1;dbname=testz","root","root");
$pdo->exec("update send set  status=1 where id='$id'");
$res=$pdo->query("select * from send where id='$id'")->fetch();
if($res['status']==1){
	echo "<a href='login.php'>激活成功</a>";
}else{
	echo "<a href='login.php'>激活失败</a>";
}