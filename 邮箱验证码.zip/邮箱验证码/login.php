<?php
session_start();
$yzm=$_SESSION['yzm'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
		<table>
			<tr>
				<td>用户名</td>
				<td><input type="text" name="user" id="user"></td>
			</tr>
			<tr>
				<td>密码</td>
				<td><input type="text" name="pwd" id="pwd"></td>
			</tr>
			<tr>
				<td>邮箱</td>
				<td><input type="text" name="email" id="email"></td>
			</tr>
			<input type="hidden" id="yz"  value="<?php echo $yzm ?>"> 
			<tr>
				<td>手机号</td>
				<td><input type="text" name="tel" id="tel" id="tel"></td>
				
				
			</tr>
			<tr>
				<td>验证码</td>
				<td><input type="text" id="ma"><input type="button" id="yzm" value="发送验证码"></td>
			</tr>
			<tr>
				<td><input type="button" id="ti" value="登陆"></td>
			</tr>
		</table>
</body>
</html>
<script src="jquery-3.3.1.min.js"></script>
<script>
	$(document).on("click","#yzm",function(){
		tel=$("#tel").val();
			$.ajax({
				url:"dosend.php",
				type:"post",
				data:{
					tel:tel,
				},
				success:function(data){
					console.log(data);
				}
			})
			
				i=5;
			t=setInterval(function(){
				if(i>0){

					i--;
				cc=$("#yzm").val(i);
				
			}else{
				clearInterval(t);
				$("#yzm").val("发送验证码");
			}
				

			},1000)
			
	})
	

$(document).on("click","#ti",function(){
	a=$("#yz").val();
	b=$("#ma").val();
	user=$("#user").val();
	pwd=$("#pwd").val();
	tel=$("#tel").val();
email=$("#email").val();
	if(a==b){
			$.ajax({
				url:"add.php",
				datatype:"json",
				type:"post",
				data:{
					user:user,
					pwd:pwd,
					tel:tel,
					email:email,
				},
				success:function(data){
					console.log(data);
						if(data==1){
							location.href="yj.php";
						}
				}
			})
	}else{
		alert("验证码错误");
		return;
	}
})
</script>