<?php
$user=$_POST['user'];
$pwd=$_POST['pwd'];
$tel=$_POST['tel'];
$email=$_POST['email'];
echo $user;die;
$pdo=new PDO("mysql:host=127.0.0.1;dbname=testz","root","root");
$res=$pdo->exec("insert into send(user,pwd,tel,email)values('$user','$pwd','$tel','$email')");
$id=$pdo->lastInsertId();
session_start();
$_SESSION['uid']=$id;
if($res){
	echo 1;
}