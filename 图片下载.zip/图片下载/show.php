<?php
header("content-type:text/html;charset=utf8");
$link=mysqli_connect("127.0.0.1","root","","1611a");
mysqli_query($link,"set namse utf8");
$page=isset($_GET['page'])?$_GET['page']:1;
if($page<1){
	$page=1;
}
$size=3;
$sql1="select*from 11a";

$res1=mysqli_query($link,$sql1);
$arr1=mysqli_fetch_all($res1,1);
$con=count($arr1);
$end=ceil($con/$size);
if($page>$end){
	$page=$end;
}

$forset=($page-1)*$size;

$sql="select*from 11a limit $forset,$size";

$res=mysqli_query($link,$sql);
$arr=mysqli_fetch_all($res,1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<table border="1">
		<tr>
			<td>id</td>
			<td>账号</td>
			<td>密码</td>
			<td>图片</td>
			<td>操作</td>
		</tr>
		<?php foreach ($arr as $key => $value){?>
			
		
		<tr>
			<td><input type="checkbox" name="ta" value=" <?php echo $value['id']?>"> <?php echo $value['id']?></td>
			<td><?php echo $value['user']?></td>
			<td><?php echo $value['pwd']?></td>
			<td><img src="<?php echo $value['img']?>" alt="" width='100'>	</td>
			<td><a href="#" onclick="fun2(<?php echo $value['id']?>)">删除</a>|
			<a href="xia.php?filename=<?php echo $value['img']?>">下载</a></td>

		</tr>
		<?php }?>
	</table>
	<a href="show.php?page=<?php echo $page-1?>" >上一页</a>
	<a href="show.php?page=<?php echo $page+1?>" >下一页</a>
	<a href="show.php?page=1">首页</a>
	<a href="show.php?page=<?php echo $end?>">尾页</a>
	<button onclick="fun()">全选</button>
	<button onclick="fun1()">全不选</button>	
	<button onclick="fan()">反选	</button>
	<button onclick="pi()">批删</button>

</body>
</html>
<script>
	function fun(){
		a=document.getElementsByName('ta')
		for(i=0;i<a.length;i++){
			a[i].checked=true
		}
	}

		function fun1(){
		c=document.getElementsByName('ta')
		for(i=0;i<c.length;i++){
			c[i].checked=false
		}
	}

	function fan(){
		e=document.getElementsByName('ta')
		for(i=0;i<e.length;i++){
			if(e[i].checked==true){
				e[i].checked=false
			}else{
				e[i].checked=true
			}
		}
	}
function fun2(id){

	h=new XMLHttpRequest()
	h.open("get","delete.php?id="+id)
	h.send()
	h.onreadystatechange=function(){
		if(h.readyState==4&&h.status==200){
			location.href=""
		}
		
	}
}


function pi(){
	f=document.getElementsByName('ta')
	str=""
	for(i=0;i<f.length;i++){
		
		if(f[i].checked==true){
			str+=","+f[i].value
		}
	}
	id=str.substr(1)
		q=new XMLHttpRequest()
	q.open("get","delete.php?id="+id)
	q.send()
	q.onreadystatechange=function(){
		if(q.readyState==4&&q.status==200){
			location.href=""
		}
	}

}

</script>