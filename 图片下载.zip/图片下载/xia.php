<?php 
$img=$_GET['filename'];
$filename=basename($img);
header('Content-Type:image/jpg');
header('Content-Disposition:attachment;filename="'.$filename.'"');
readfile($img);
?>