<?php
header("content-type:text/html;charset=utf8");
$link=mysqli_connect("127.0.0.1","root","","1611a");
mysqli_query($link,"set namse utf8");
$file=$_FILES['img'];
$name=$_POST['user'];
$pwd=$_POST['pwd'];
$img_name=$file['name'];
$img_tmp=$file['tmp_name'];
$size=1000000;
$img_size=$file['size'];
if($img_size>$size){
	echo "<a href='shou.html'>文件超出1M</a>";
	die;

}
$type=$file['type'];
$lei=array("image/jpeg","image/png");
if(!in_array($type,$lei)){
	echo "<a href='shou.html'>格式错误</a>";
	die;

}
$di="img/".date("Ymdhis",time()).".gif";
move_uploaded_file($img_tmp,$di );
$sql="insert into 11a values(null,'$name','$pwd','$di')";
$res=mysqli_query($link,$sql);
if($res){
	echo "<a href='show.php'>上传成功</a>";
}else{
	echo "<a href='shou.html'>上传失败</a>";
}
