<?php
header("content-type:text/html;charset=utf8");
$link=mysqli_connect("127.0.0.1","root","","1611a");
mysqli_query($link,"set namse utf8");
$id=$_GET['id'];
$sql="delete from 11a where id in($id)";
$res=mysqli_query($link,$sql);
if($res){
	echo "ok";
}